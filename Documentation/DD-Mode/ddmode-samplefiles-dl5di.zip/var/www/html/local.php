<?php
#
# Modify logPath, callsign, title, sponsor, registerURL to match your station
#
$logPath = '/var/log/dstar';
$callsign = 'DB0MYK';
$title = $callsign . ' - STARnet Digital and ircDDBGateway Repeater';
$sponsor = 'PRGM e.V.';
$registerURL = 'http://dstar.prgm.org/dstar-reg.htm'; #change to a local Icom stack for USROOT registration
$starLogPath = $logPath . '/STARnet.log';
$linkLogPath = $logPath . '/Links.log';
$hdrLogPath = $logPath . '/Headers.log';
$gatewayConfigPath = '.ircDDB Gateway';
#$gatewayConfigPath = '/root/.StarNet Server';
// added values for STARnet Server (flip to true and set lat and long)
$STARnetServer = false;
$sslatitude = '0.0';
$sslongitude = '0.0';
if ($STARnetServer) {
        $title = $callsign . ' - STARnet Digital Server';
} else {
        $title = $callsign . ' - ircDDBGateway Repeater and STARnet Digital Server';
        }

# special DD-mode settings (DL5DI 2011/09/18)
$leasefile = '/var/lib/dhcpd/dhcpd.leases';
$IPlog = $logPath . 'IP.log';

?>
