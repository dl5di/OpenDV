<?php
require_once("dhcpconfig.php");
require_once("dhcpfunctions.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="css/dhcpstyle.css">
	<title>DD-Mode DHCP-leases</title>
	<script language="JavaScript" type="text/javascript">
		function sortby (to,p) {
			var myForm = document.createElement("form");
			myForm.method="post" ;
			myForm.action = to ;
			for (var k in p) {
				var myInput = document.createElement("input") ;
				myInput.setAttribute("name", k) ;
				myInput.setAttribute("value", p[k]);
				myForm.appendChild(myInput) ;
			}
			document.body.appendChild(myForm) ;
			myForm.submit() ;
			document.body.removeChild(myForm) ;
		}
	</script>
</head>
<body>
<center>
<h2>Current DHCP IP Addresses (Leases)</h2>
</center>

<?php
//read leases file
if (isset($_POST['searchfilter'])) {
	$searchfilter = $_POST['searchfilter'];
} else {
	$searchfilter = "";
}

if (isset($_POST['sort_column'])) {
	$sort_column = $_POST['sort_column'];
} else {
	$sort_column = 0;
}

if (file_exists($dhcpd_leases_file) && is_readable($dhcpd_leases_file))
{
	$open_file = fopen($dhcpd_leases_file, "r") or die("Unable to open DHCP leases file.");
	if ($open_file)
	{
		if ($searchfilter != "") {
			$searchfiledmsg = $searchfilter;
		} else {
			$searchfiledmsg = "Type to search";
		}
		//Create a 2-dimensional table for the dhcplease file
		$dhcptable = array(array());
		//Call the dhcplease file parser
		$dhcptable = parser($open_file);

		?>

		<form action = "index.php"  accept-charset="UTF-8" method="post" id="search-form">
		Search Filter:
		<input type="text" maxlength="255" name="searchfilter" id="searchfilter" size="20" placeholder="Enter Search" 
		<?php
			echo " value = '" . $searchfilter . "'>";
		?>
		<input type="submit" name="Search" value="Search">

		<?php
		if ($searchfilter != "")
			echo "<a href='index.php'>Clear Search</a>\n";
		?>
		
		</form>
		<br><br>
		<?php
			echo "<p>Total number of entries in DHCP lease table: " . count($dhcptable) . "</p>\n";
		?>

		<table>
		<tr class="table_title">
		<td width="14%"><b>
			<a href="javascript:sortby('index.php',{sort_column:'-1',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_down.png" alt="Sort Descending" title="Sort Descending">
			</a>
			Callsign
			<a href="javascript:sortby('index.php',{sort_column:'1',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_up.png" alt="Sort Ascending" title="Sort Ascending">
			</a>
		</b></td>

		<td width="14%"><b>
			<a href="javascript:sortby('index.php',{sort_column:'-2',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_down.png" alt="Sort Descending" title="Sort Descending">
			</a>
			IP Address
			<a href="javascript:sortby('index.php',{sort_column:'2',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_up.png" alt="Sort Ascending" title="Sort Ascending">
			</a>
		</b></td>

		<td width="14%"><b>
			<a href="javascript:sortby('index.php',{sort_column:'-3',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_down.png" alt="Sort Descending" title="Sort Descending">
			</a>
			Start Time (UTC)
			<a href="javascript:sortby('index.php',{sort_column:'3',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_up.png" alt="Sort Ascending" title="Sort Ascending">
			</a>
		</b></td>

		<td width="14%"><b>
			<a href="javascript:sortby('index.php',{sort_column:'-5',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_down.png" alt="Sort Descending" title="Sort Descending">
			</a>
			End Time (UTC)
			<a href="javascript:sortby('index.php',{sort_column:'5',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_up.png" alt="Sort Ascending" title="Sort Ascending">
			</a>
		</b></td>

		<td width="14%"><b>
			<a href="javascript:sortby('index.php',{sort_column:'-6',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_down.png" alt="Sort Descending" title="Sort Descending">
			</a>
			MAC Address
			<a href="javascript:sortby('index.php',{sort_column:'6',searchfilter:'<?php echo $searchfilter;?>'})">
				<img src="images/arrow_up.png" alt="Sort Ascending" title="Sort Ascending">
			</a>
		</b></td>

		</tr>
		<?php
		//Display the dhcp lease table using the filter and ordered
		print_table($dhcptable, $searchfilter, $sort_column);
		fclose($open_file);
		?>
		</table>
		<?php
	}
}
else
{
	echo "<p class='error'>The DHCP leases file does not exist or does not have sufficient read privileges.</p>";
}
?>

<br><hr>
<center><a href="http://www.rivetcode.com">phpdhcpd</a>
<br>Version: <?php echo $version;?></center>
</body>
</html>

