<?php


function parser($open_file) 
{
	$line_number = 0;
	$row_array = array(array());
	while (!feof($open_file))
	{	
		$read_line = fgets($open_file, 4096);
		if (substr($read_line, 0, 1) != "#") //check for comment (skip)
		{
			$tok = strtok($read_line, " ");
			if ($tok == "lease")
			{
				$row_array[$line_number] = initialize_array();
				$row_array[$line_number][0] = strtok(" ")."\n";
			}
			else if ($tok == "starts")
			{
				$row_array[$line_number][1] =   intToDay(strtok(" "));
				$row_array[$line_number][1] = $row_array[$line_number][1]." - " . strtok(" ") . " ";
				$time = strtok(" ");
				$time = str_replace(";", "", $time);
				$row_array[$line_number][1] = $row_array[$line_number][1].$time ;
			}
			else if ($tok == "ends")
			{
				$row_array[$line_number][2] = intToDay(strtok(" "));
				$row_array[$line_number][2] = $row_array[$line_number][2]." - " . strtok(" ") . " ";
				$time = strtok(" ");
				$time = str_replace(";", "", $time);
				$row_array[$line_number][2] = $row_array[$line_number][2].$time ;
			}	
			else if ($tok == "hardware")
			{
				$row_array[$line_number][3] = strtok(" ") . " - ";
				$MAC = strtok(" ");
				$MAC = strtoupper(str_replace(";", "", $MAC));
				$MAC = strtoupper(str_replace("ethernet - ", "", $MAC));
				$row_array[$line_number][3] = $MAC." (".getmacvendor($MAC).")";
				$row_array[$line_number][4] = getcallsign($MAC);
			}
			else if ($tok == "}\n")
			{
				$row_array[$line_number][5] = $row_array[$line_number][4];
				$line_number++;
			}
			
		}
	}
	return $row_array;
}


function intToDay($integer)
{
	if ($integer == 0)
	return "Sunday";
	else if ($integer == 1)
	return "Monday";
	else if ($integer == 2)
	return "Tuesday";
	else if ($integer == 3)
	return "Wednesday";
	else if ($integer == 4)
	return "Thursday";
	else if ($integer == 5)
	return "Friday";
	else
	return "Saturday";
}

function initialize_array()
{
	$row_array = array();
	for ($i = 0; $i < 7; $i++) {
		$row_array[$i] = "-";
	}
	return $row_array;
}

function print_line($row, $css_num)
{
	for ($i = 0; $i < 5; $i++) {
		switch ($i) {
		case 0: 
			//Callsign
			echo "<tr class='row".$css_num."'><td>".$row[4]."</td>\n"; 
			break;
		case 1: 
			//IP Address
			echo "<td>".$row[0]. "</td>\n"; 
			break;
		case 2: 
			//Start Time
			echo "<td>".$row[1]. "</td>\n"; 
			break;
		case 3: 
			//End Time
			echo "<td>".$row[2]. "</td>\n"; 
			break;
		case 4: 
			//MAC Address
			echo "<td>".$row[3]."</td>\n"; 
			break;
		}
	}
}

function compare_ip($a, $b) 
{
	return strnatcmp($a[0], $b[0]);
}

function compare_start_time($a, $b) 
{
	return strnatcmp($a[1], $b[1]);
}

function compare_end_time($a, $b) 
{
	return strnatcmp($a[2], $b[2]);
}

function compare_mac($a, $b)
{ 
	return strnatcmp($a[3], $b[3]);
}

function compare_call($a, $b)
{ 
	return strnatcmp($a[4], $b[4]);
}

function getmacvendor($mac_unformated)
{
	//Can be retrived on nmap http://nmap.org/book/nmap-mac-prefixes.html 
	//or via http://standards.ieee.org/develop/regauth/oui/oui.txt
	//Location of the mac vendor list file
	$mac_vendor_file = "./nmap-mac-prefixes";

	$mac = substr(strtoupper(str_replace(array(":"," ","-"), "", $mac_unformated)),0,6);

	$open_file = fopen($mac_vendor_file, "r") or die("Unable to open MAC VENDOR file.");
	if ($open_file)
	{
		while (!feof($open_file))
		{
			 $read_line = fgets($open_file, 4096);
			 if (substr($read_line, 0, 6) == $mac) {
				return substr($read_line, 7, -1);
			 }
		}
		
		fclose($open_file);
	}
	return "Unknown device";
}


function print_table($dhcptable, $searchfilter, $sort_column)
{
	$order = 0;
	switch ($sort_column) {
		case 1: 
			usort($dhcptable, 'compare_ip');
			break;
		case 2: 
			usort($dhcptable, 'compare_start_time');
			break;
		case 3: 
			usort($dhcptable, 'compare_end_time'); 
			break;
		case 4: 
			usort($dhcptable, 'compare_mac');
			break;
		case 5:
			usort($dhcptable, 'compare_callsign');
			break;
		case -1: 
			usort($dhcptable, 'compare_ip');
			$order=-1;
			break;
		case -2: 
			usort($dhcptable, 'compare_start_time');
			$order=-1;
			break;
		case -3: 
			usort($dhcptable, 'compare_end_time'); 
			$order=-1;
			break;
		case -4: 
			usort($dhcptable, 'compare_mac');
			$order=-1;
			break;
		case -5: 
			usort($dhcptable, 'compare_callsign');
			$order=-1;
			break;
	}
	
	
	$displayed_line_number = 0;
	if ($order >= 0) {
		//Read every line of the table
		for ($line = 0; $line < count($dhcptable); $line++){
			//Check if the line contains the searched request
			if ($searchfilter != "")
			{
				$displayline = 0;
				for ($i = 0; $i < 7; $i++){
					if (stristr (strtolower($dhcptable[$line][$i]),strtolower($searchfilter))== TRUE) {
						$displayline = 1;
					}
				}

				if ($displayline == 1) {
					$css_num = $displayed_line_number % 2;
					print_line($dhcptable[$line], $css_num);
					$displayed_line_number++;
				}
			}
			else
			{
				$css_num = $displayed_line_number % 2;
				print_line($dhcptable[$line], $css_num);
				$displayed_line_number++;
			}
		}
	}
	else
	{
		for ($line = count($dhcptable)-1; $line >= 0; $line--){
			//Check if the line contains the searched request
			if ($searchfilter != "")
			{
				$displayline = 0;
				for ($i = 0; $i < 7; $i++){
					if(stristr (strtolower($dhcptable[$line][$i]), strtolower($searchfilter))== TRUE) {
						$displayline = 1;
					}
				}

				if ($displayline == 1) {
					$css_num = $displayed_line_number % 2;
					print_line($dhcptable[$line], $css_num);
					$displayed_line_number++;
				}
			}
			else
			{
				$css_num = $displayed_line_number % 2;
				print_line($dhcptable[$line], $css_num);
				$displayed_line_number++;
			}
		}
	}
}

function getcallsign($mac)
{
	//mac-add<->callsign assignment can be found in DDMode.log which is created in logpath of ircDDBGateway
	//path needs to be set in config.php

	$ddmode_log = "/var/log/dstar/DDMode.log";
	$open_file = fopen($ddmode_log, "r") or die("Unable to open DDMode-Logfile.");
	if ($open_file)
	{
		$mac = rtrim($mac);
		while (!feof($open_file))
		{
			 $read_line = fgets($open_file, 4096);
			 if (strtoupper(substr($read_line, 21, 17)) == $mac) {
				return substr($read_line, 39, 8);
			 }
		}
		
		fclose($open_file);
	}
#	$res = "/".$mac."/".strtoupper(substr($read_line, 21, 17))."/";
	return "********$res";
}

?>
