<?php
if(strstr($_SERVER['HTTP_USER_AGENT'],'MSIE')) header("Location: index2.php");

require_once('local.php');

$dom = new DOMDocument("1.0");
$configs = array();

if ($configfile = fopen($gatewayConfigPath,'r')) {
        while ($line = fgets($configfile)) {
                list($key,$value) = split("=",$line);
                $value = trim(str_replace('"','',$value));
                if ($key != 'ircddbPassword' && strlen($value) > 0)
                $configs[$key] = $value;
        }

}

if ($STARnetServer) { 
	$configs['gatewayCallsign'] = str_pad($callsign,7) . 'G';
	$configs['latitude'] = $sslatitude;
	$configs['longitude'] = $sslongitude;
}

function buildgroupinfo($dom,$configs,$starLogPath) {
	

	$groupsx = array();
	if ($starLog = fopen($starLogPath,'r')) {
		
		while($logLine = fgets($starLog)) {
		        preg_match_all('/^(.{19}).*(Adding|Removing) (.{8}).*StarNet group (.{8}).*$/',$logLine,$matches);
		        $groupz = $matches[4][0];
		        $member = $matches[3][0];
		        $action = $matches[2][0];
		        $date = strtotime($matches[1][0] . ' UTC');
		        if ($action == 'Adding'){ $groupsx[$groupz][$member] = date('Y-m-d H:i:s T',$date); } else
		        if ($action == 'Removing'){
		                unset($groupsx[$groupz][$member]);
		        }
		}
		fclose($starLog);
	}

        $attributes = array( "starNetBand" => 'band',
                        "starNetInfo" => 'info',
                        "starNetUserTimeout" => 'userTimeout',
                        "starNetGroupTimeout" => 'groupTimeout',
			"starNetReflector" => 'reflector',
			"starNetLogoff" => 'logoffcall' );

        $search = "starNetCallsign";
        $found = false;
        $callBase = substr($configs["gatewayCallsign"],0,7);
        $groupsi = $dom->createElement("STARnetGroupsInfo");
        $keys = array_keys($configs);
        foreach($keys as $key) {
                if ($pos = strstr($key,$search)) {
                        $found = true;
			$gcall = $configs[$key];
                        $digits = str_replace($search,"",$key);
                        $group = $dom->createElement("group");
                        $groupsi->appendChild($group);
			$callj = $dom->createAttribute("callsign");
			$group->appendChild($callj);
                        $groupcall = $dom->createTextNode($gcall);
                        $callj->appendChild($groupcall);
                        $attrkeys = array_keys($attributes);
                        foreach($attrkeys as $attrkey) {
                                $configKey = $attrkey . $digits;
				if (array_key_exists($configKey,$configs)) {
	                                $attribute = $dom->createAttribute($attributes[$attrkey]);
	                                $group->appendChild($attribute);
	                                if ($attrkey == "starNetBand") $value = $dom->createTextNode($callBase . $configs[$configKey]);
	                                else $value = $dom->createTextNode($configs[$configKey]);
	                                $attribute->appendChild($value);
				}
                        }
			$gcallz = str_pad($gcall,8);
			$keyzx = array_keys($groupsx[$gcallz]);
			foreach ($keyzx as $m) {
					$subscriber = $dom->createElement("subscriber");
					$group->appendChild($subscriber);
					$subtime = $dom->createAttribute("timestamp");
					$subscriber->appendChild($subtime);
					$ts = $groupsx[$gcallz][$m];
					$subtimetext = $dom->createTextNode($ts);
					$subtime->appendChild($subtimetext);
					$subcallsign = $dom->createTextNode($m);
					$subscriber->appendChild($subcallsign);
			}
                }
        }
        if ($found) {
                return($groupsi);
        } else {
                return($dom->createComment("No Groups"));
        }
}


function buildrepeaterinfo($dom,$configs) {

//        $attributes = array ( "range", "rangeKms", "frequency", "offset", "agl", "atStartup", "reconnect" , "ddMode" );
        $attributes = array ( "frequency", "offset", "agl", "atStartup", "reconnect" , "ddMode" );
        $search = "repeaterBand";
        $found = false;
        $repeaters = $dom->createElement("repeaterinfo");
        $callBase = substr($configs["gatewayCallsign"],0,7);
        $keys = array_keys($configs);
        foreach($keys as $key) {
                if ($pos = strstr($key,$search)) {
                        $found = true;
                        $digits = str_replace($search,"",$key);
                        $repeater = $dom->createElement("repeater");
                        $repeaters->appendChild($repeater);
                        $rptrcall = $dom->createTextNode($callBase . $configs[$key]);
                        $repeater->appendChild($rptrcall);
                        foreach($attributes as $attr) {
                                $configKey = $attr . $digits;
                                $attribute = $dom->createAttribute($attr);
                                $repeater->appendChild($attribute);
                                $value = $dom->createTextNode($configs[$configKey]);
                                $attribute->appendChild($value);
                        }
                }
        }
        if ($found) {
                return($repeaters);
        } else {
                return($dom->createComment("No Repeaters"));
        }
}

function baseValues($dom,$root,$configs) {
        
        $generalAttr = array("gatewayCallsign","hardwareType","latitude","longitude","ircddbHostname","ircddbUsername",
                        "aprsHostname","dplusEnabled","dplusLogin","language","infoEnabled","echoEnabled",
                        "logEnabled","remoteEnabled","repeaterTapEnabled","dratsEnabled","description1",
                        "description2","url","aprsEnabled","dextraEnabled");
        foreach($generalAttr as $attr) {
                if (array_key_exists($attr,$configs)) {
                        $element = $dom->createElement($attr);
                        $root->appendChild($element);
                        $value = $dom->createTextNode($configs[$attr]);
                        $element->appendChild($value);
                } else {
                        $comment = $dom->createComment("No " . $attr);
                        $root->appendChild($comment);
                }
        }
}

function addlinks($dom,$parent,$linkLogPath) {
	$linksdom = $dom->createElement("links");

	if ($linkLog = fopen($linkLogPath,'r')) {
		$i=0;
		while ($linkLine = fgets($linkLog)) {
// Reflector-Link, sample: 2011-09-22 02:15:06: DExtra link - Type: Repeater Rptr: DB0LJ  B Refl: XRF023 A Dir: Outgoing
		        if(preg_match_all('/^(.{19}).*(D[A-Za-z]*).*Type: ([A-Za-z]*).*Rptr: (.{8}).*Refl: (.{8}).*Dir: (.*)$/',$linkLine,$linx) > 0){
		    	    $linkDate = strtotime($linx[1][0] . ' UTC');
		    	    $protocol = $linx[2][0];
		    	    $linkType = $linx[3][0];
		    	    $linkRptr = $linx[4][0];
		    	    $linkRefl = $linx[5][0];
		    	    $linkDir = $linx[6][0];
			} else {
// Dongle-Link, sample: 2011-09-24 07:26:59: DPlus link - Type: Dongle User: DC1PIA   Dir: Incoming
		    	    preg_match_all('/^(.{19}).*(D[A-Za-z]*).*Type: ([A-Za-z]*).*User: (.{8}).*Dir: (.*)$/',$linkLine,$linx);
		    	    $linkDate = strtotime($linx[1][0] . ' UTC');
		    	    $protocol = $linx[2][0];
		    	    $linkType = $linx[3][0];
		    	    $linkRptr = "";
		    	    $linkRefl = $linx[4][0];
		    	    $linkDir = $linx[5][0];
			}
			$linkRPT = $dom->createElement("repeater");
			$linksdom->appendChild($linkRPT);
			$tsAttr = $dom->createAttribute("timestamp");
			$tsVal  = $dom->createTextNode(date('Y-m-d H:i:s T',$linkDate));
			$tsAttr->appendChild($tsVal);
			$linkRPT->appendChild($tsAttr);
			$protoAttr = $dom->createAttribute("protocol");
			$protoVal = $dom->createTextNode($protocol);
			$protoAttr->appendChild($protoVal);
			$linkRPT->appendChild($protoAttr);
			$typeAttr = $dom->createAttribute("type");
			$typeVal = $dom->createTextNode($linkType);
			$typeAttr->appendChild($typeVal);
			$linkRPT->appendChild($typeAttr);
			$reflAttr = $dom->createAttribute("target");
			$reflVal = $dom->createTextNode($linkRefl);
			$reflAttr->appendChild($reflVal);
			$linkRPT->appendChild($reflAttr);
			$dirAttr = $dom->createAttribute("direction");
			$dirVal = $dom->createTextNode($linkDir);
			$dirAttr->appendChild($dirVal);
			$linkRPT->appendChild($dirAttr);
			$callVal = $dom->createTextNode($linkRptr);
			$linkRPT->appendChild($callVal);
			$i++;
		}
		fclose($linkLog);
		if ($i > 0) {
			$parent->appendChild($linksdom);
		}
	}

}
function addgroups($dom,$parent,$starLogPath) {
}

function addstations($dom,$parent,$hdrLogPath) {

	if ($hdrLog = fopen($hdrLogPath,'r')) {
		$hdrs = array();
	
		while ($hdrlin = fgets($hdrLog)) {
		        $pos = strpos($hdrlin,"Repeater header");
		        if ($pos !== false) {
		                preg_match_all('/^(.{19}).*My: (.{8}).*\/(.{4}).*Your: (.{8}).*Rpt1: (.{8}).*$/',$hdrlin,$headrs);
		                $datestamp = strtotime($headrs[1][0] . ' UTC');
		                $station = $headrs[2][0];
		                $comment4 = $headrs[3][0];
		                $your = $headrs[4][0];
		                $rptr1 = $headrs[5][0];
		
		                if ( preg_match('/([A-Z 0-9]{8})/',$station) == 1) $hdrs[$rptr1][$station . '/' . $comment4] = date('Y-m-d H:i:s T',$datestamp) . '|' . $your;
		        }
		}
		fclose($hdrLog);
		if (count($hdrs) > 0) {
			$hdrdom = $dom->createElement("rf");
			$parent->appendChild($hdrdom);
			$keysrptr = array_keys($hdrs);
			foreach($keysrptr as $rptrkey) {
				$rptrg = $dom->createElement("repeater");
				$hdrdom->appendChild($rptrg);
				$rptrcall = $dom->createElement("call");
				$rptrg->appendChild($rptrcall);
				$rptrcs = $dom->createTextNode($rptrkey);
				$rptrcall->appendChild($rptrcs);
				$stationkeys = array_keys($hdrs[$rptrkey]);
				foreach($stationkeys as $stationcall) {
					$station = $dom->createElement("station");
					$rptrg->appendChild($station);
					$scall = $dom->createTextNode($stationcall);
					$station->appendChild($scall);
					list($date,$ur) = split("\|",$hdrs[$rptrkey][$stationcall]);
					$datets = $dom->createAttribute("timestamp");
					$station->appendChild($datets);
					$datev = $dom->createTextNode($date);
					$datets->appendChild($datev);
					$urtag = $dom->createAttribute("destination");
					$station->appendChild($urtag);
					$urval = $dom->createTextNode($ur);
					$urtag->appendChild($urval);
				}
			}
		}
	}
}

header("Content-Type: text/xml");
$xslsheet = $dom->createProcessingInstruction('xml-stylesheet','type="text/xsl" href="STARnet4.xsl"');
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;
$dom->appendChild($xslsheet);
$root = $dom->createElement("ircDDBGateway");
$dom->appendChild($root);
$ver = $dom->createElement("version");
$root->appendChild($ver);
$vert = $dom->createTextNode("1.2");
$ver->appendChild($vert);
$dt = $dom->createElement("datetime");
$root->appendChild($dt);
$dtstr = $dom->createTextNode(date('Y-m-d H:i:s T'));
$dt->appendChild($dtstr);
$gatecall = $dom->createElement("server");
$root->appendChild($gatecall);
$gatecallv = $dom->createTextNode($callsign);
$gatecall->appendChild($gatecallv);
$sponsorx = $dom->createElement("sponsor");
$root->appendChild($sponsorx);
$sname = $dom->createTextNode($sponsor);
$sponsorx->appendChild($sname);
$regnode = $dom->createElement("registerURL");
$root->appendChild($regnode);
$regtext = $dom->createTextNode($registerURL);
$regnode->appendChild($regtext);
$titlenode = $dom->createElement("title");
$root->appendChild($titlenode);
$titlestring = $dom->createTextNode($title);
$titlenode->appendChild($titlestring);
baseValues($dom,$root,$configs);
$root->appendChild(buildgroupinfo($dom,$configs,$starLogPath));
$root->appendChild(buildrepeaterinfo($dom,$configs));
#addgroups($dom,$root,$starLogPath);
addstations($dom,$root,$hdrLogPath);
addlinks($dom,$root,$linkLogPath);
echo $dom->saveXML();
?>
