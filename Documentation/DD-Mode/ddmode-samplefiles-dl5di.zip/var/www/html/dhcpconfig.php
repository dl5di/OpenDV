<?php
//phpdhcpd config file

//Location of dhcpd.leases file
$dhcpd_leases_file = "/var/lib/dhcpd/dhcpd.leases";
$ddmode_log = "/var/log/dstar/DDMode.log";

//If password is left blank, NO authentication will
//be required and the page will be visible to anyone.
//However, if it is NOT blank, the only
//way to view the page is by entering the correct password.
//This password is in cleartext, if other people can access
//this file, this is NOT secure.  For true security, use
//Apache digest authentication or other methods such as
//an htaccess file.
$password = "";


//phpdhcpd version
//You don't have to change this
$version = "0.5 / modified for DStar-DD by DL5DI (20110924)";
?>
